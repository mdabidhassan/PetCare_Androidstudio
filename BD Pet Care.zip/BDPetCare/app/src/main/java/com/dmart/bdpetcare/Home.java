package com.dmart.bdpetcare;

import android.app.DirectAction;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.constants.ScaleTypes;
import com.denzcoskun.imageslider.models.SlideModel;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;


public class Home extends Fragment {
   ImageView CatView,dogview, infoview,fosterview,petbazar,gobadi,direction,hospital,Videos;
    ImageSlider imageSlider;
    ImageView what;
    ArrayList<HashMap<String,String>> array=new ArrayList<>();
    HashMap<String ,String>hashmap;

    AdView adview,adView2;

ImageView image;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
      View view = inflater.inflate(R.layout.fragment_home, container, false);

        if (container != null) {
            container.removeAllViews();

        }

        if (Build.VERSION.SDK_INT>= Build.VERSION_CODES.LOLLIPOP){
            requireActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            requireActivity().getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
            requireActivity().getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
            requireActivity().getWindow().setStatusBarColor(Color.TRANSPARENT);

        }else {

            requireActivity().getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

        }

        MobileAds.initialize(getActivity(), new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });

      gobadi=view.findViewById(R.id.otherss);
      hospital=view.findViewById(R.id.hospital);
      Videos=view.findViewById(R.id.vdf);
        direction =view.findViewById(R.id.direction);
petbazar=view.findViewById(R.id.petgoods);
      CatView=view.findViewById(R.id.cardone);
       fosterview=view.findViewById(R.id.foster);
      dogview=view.findViewById(R.id.dog);
       infoview=view.findViewById(R.id.infod);

       gobadi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Toast.makeText(getContext(), "শিঘ্রই আসবে", Toast.LENGTH_SHORT).show();
            }
        });
       direction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getActivity().getApplication(),Webv.class);

                intent.putExtra("url","https://sites.google.com/view/vetdirection");
                startActivity(intent);
            }
        });

        hospital.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getActivity().getApplication(),Webv.class);

                intent.putExtra("url","https://sites.google.com/view/sooonpub/home");
                startActivity(intent);
            }
        });
        Videos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent intent= new Intent(getActivity().getApplication(), Video.class);
                startActivity(intent);
            }
        });
        petbazar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(getActivity().getApplication(),PetBazar.class);
                startActivity(intent);
            }
        });

       petbazar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(getActivity().getApplication(),PetBazar.class);
                startActivity(intent);
            }
        });

       CatView.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Intent intent= new Intent(getActivity().getApplication(),Catsolution.class);
               startActivity(intent);
           }
       });
       infoview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(getActivity().getApplication(),Information.class);
                startActivity(intent);
            }
        });

        fosterview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(getActivity().getApplication(),FOSTERLOG.class);
                startActivity(intent);
            }
        });

        dogview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(getActivity().getApplication(),DOGINFO.class);
                startActivity(intent);
            }
        });

        //start image slider........................................




        String url="https://petcarebd.xyz/petcarebd/imageslider";

        JsonArrayRequest jsnarry =new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {

                try {
                    for (int x=0;x<response.length();x++){


                        JSONObject object= response.getJSONObject(x);
                        String version=object.getString("image");
                        String name=object.getString("Name");
                        String version2=object.getString("image2");
                        String name2=object.getString("Name2");

                        String version3=object.getString("image3");
                        String name3=object.getString("Name3");


                        // in Activity
                        imageSlider = view.findViewById(R.id. image_slider);
                        ArrayList<SlideModel> imageList = new ArrayList<>();

                        imageList.add(new SlideModel(version, name, null));
                        imageList.add(new SlideModel(version2, name2, null));
                        imageList.add(new SlideModel(version3, name3, null));
                        imageSlider.setImageList(imageList, ScaleTypes.CENTER_CROP);


                                //Toast.makeText(getActivity(), name, Toast.LENGTH_SHORT).show();




                        //..................end image slider

                    }









                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }



        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {


            }
        });

//..2.................................................................................................................//
        RequestQueue queue= Volley.newRequestQueue(getActivity().getApplicationContext());
        queue.add(jsnarry);

        return view;



    }
}