package com.dmart.bdpetcare;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainVideo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_video);
    }
}