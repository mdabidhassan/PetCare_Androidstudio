package com.dmart.bdpetcare;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity {
   MaterialToolbar toolbar;
    TabLayout tab;
    DrawerLayout drawer;
   NavigationView navigationView;
    LinearLayout linear,lincat,lingoods;
    InterstitialAd mInterstitialAd;
    Button button;
    Spinner spinner;
    String[] country = {"Barishal", "Dhaka", "Sylhet", "Khulna", "Chattogram", "Rangpur"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

      
        MobileAds.initialize(MainActivity.this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });


        toolbar=findViewById(R.id.tool);
navigationView=findViewById(R.id.nav);
        tab=findViewById(R.id.tab);
        drawer=findViewById(R.id.dwr);

        ActionBarDrawerToggle togle=new ActionBarDrawerToggle(MainActivity.this,drawer,toolbar,R.string.Close_drawer,R.string.open_drawer);
        drawer.addDrawerListener(togle);







        FragmentManager fm=getSupportFragmentManager();
        FragmentTransaction ft=fm.beginTransaction();

        ft.add(R.id.frame,new Home());
        ft.commit();

        tab.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                int position = tab.getPosition();

                if (position==0){
                    FragmentManager fm=getSupportFragmentManager();
                   FragmentTransaction ft=fm.beginTransaction();
                    ft.add(R.id.frame,new Home());
                    ft.commit();

                }

                else if (position==1){
                    FragmentManager fm=getSupportFragmentManager();
                    FragmentTransaction ft=fm.beginTransaction();
                    ft.add(R.id.frame,new Catdoctor());
                    ft.commit();


                }

                else if (position==2){

                    FragmentManager fm=getSupportFragmentManager();
                    FragmentTransaction ft=fm.beginTransaction();
                    ft.add(R.id.frame,new Dhakadoc() );
                   ft.commit();



                }

                else if (position==3){

                   FragmentManager fm=getSupportFragmentManager();
                    FragmentTransaction ft=fm.beginTransaction();
                    ft.add(R.id.frame,new Volunteer() );
                    ft.commit();



                }





           }


            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });




        // nav.................................................................

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId()==R.id.wlccu){
                    Intent intent = new Intent(MainActivity.this,Wlccu.class);

                    startActivity(intent);

                    drawer.closeDrawer(GravityCompat.START);
                } else if (item.getItemId()==R.id.share) {

                    String url = "https://play.google.com/store/apps/details?id=com.dmart.bdpetcare";

                    // Create an Intent with the ACTION_VIEW action
                    Intent intent = new Intent(Intent.ACTION_VIEW);

                    // Set the data of the Intent to the specified URL
                    intent.setData(Uri.parse(url));

                    // Start the activity using the created Intent
                    startActivity(intent);
                    drawer.closeDrawer(GravityCompat.START);

                }else if (item.getItemId()==R.id.join) {
                    String url = "https://www.facebook.com/profile.php?id=61551730176797";

                    // Create an Intent with the ACTION_VIEW action
                    Intent intent = new Intent(Intent.ACTION_VIEW);

                    // Set the data of the Intent to the specified URL
                    intent.setData(Uri.parse(url));

                    // Start the activity using the created Intent
                    startActivity(intent);
                    drawer.closeDrawer(GravityCompat.START);

                }else if (item.getItemId()==R.id.policyp) {

                        Intent intent = new Intent(MainActivity.this,Webv.class);

                        intent.putExtra("url","https://sites.google.com/view/bdpetcarepolicy/home");
                        startActivity(intent);
                    drawer.closeDrawer(GravityCompat.START);


                    }
                return false;
            }
        });

//nav...end..........................................................................
toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
    @Override
    public boolean onMenuItemClick(MenuItem item) {
        if (item.getItemId()==R.id.messenger){
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("fb://messaging/" + "61551730176797"));
            startActivity(i);


        } else if (item.getItemId()==R.id.whatsapp) {
            String number ="+8801609106180";
            String url = "https://api.whatsapp.com/send?phone="+number;
            Intent wpIntent = new Intent(Intent.ACTION_VIEW);
            wpIntent.setData(Uri.parse(url));
            startActivity(wpIntent);
        }
        return false;
    }
});

       // spinner = findViewById(R.id.spiiner);

        //ArrayAdapter<String> adapter=new ArrayAdapter<String>( MainActivity.this, R.layout.resource_item,country
       // );
      //  adapter.setDropDownViewResource(R.layout.resource_item);
      //  spinner.setAdapter(adapter);

        //spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
          //  @Override
          //  public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

               // String value= adapterView.getItemAtPosition(i).toString();
                //if (value=="Barishal"){


                            //FragmentManager fm = getSupportFragmentManager();
                          //  FragmentTransaction ft = fm.beginTransaction();
                           // ft.add(R.id.feame, new Dhakadoc());
                           // ft.commit();




                //} else if (value=="Dhaka") {

                           // FragmentManager fm = getSupportFragmentManager();
                          //  FragmentTransaction ft = fm.beginTransaction();
                          //  ft.add(R.id.feame, new Dhakadoc());
                           // ft.commit();


              //  } else if (value=="Sylhet") {


                          //  Toast.makeText(MainActivity.this,"soon will be open",Toast.LENGTH_SHORT).show();


                //} else if (value=="Barishal") {



                            //Toast.makeText(MainActivity.this,"soon will be open",Toast.LENGTH_SHORT).show();


                //}
               // else if (value=="Khulna") {



                           // Toast.makeText(MainActivity.this,"soon will be open",Toast.LENGTH_SHORT).show();


               // }else if (value=="Chattogram") {



                           // Toast.makeText(MainActivity.this,"soon will be open",Toast.LENGTH_SHORT).show();



              //  }
               // else if (value=="Rangpur") {



                           // Toast.makeText(MainActivity.this,"soon will be open",Toast.LENGTH_SHORT).show();



              //  }
           // }

           // @Override
           // public void onNothingSelected(AdapterView<?> adapterView) {

           // }
       // });





            }
    private static final int TIME_INTERVAL = 2000; // # milliseconds, desired
    private long mBackPressed;

    // When user click bakpress button this method is called
    @Override
    public void onBackPressed() {
        // When user press back button

        if (mBackPressed + TIME_INTERVAL > System.currentTimeMillis()) {
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_HOME);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);

        } else {

            Toast.makeText(getBaseContext(), "Press again to exit",
                    Toast.LENGTH_SHORT).show();


        }

        mBackPressed = System.currentTimeMillis();



    } // end of onBackpressed method

}