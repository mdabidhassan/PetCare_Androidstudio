package com.dmart.bdpetcare;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.ProgressBar;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

public class ALLvideo extends AppCompatActivity {
    WebView web;
    AdView adview,adView2;
    ProgressBar probar2;
    public static String video="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_allvideo);
        probar2=findViewById(R.id.progressBar2);
        probar2.setVisibility(View.VISIBLE);

        web=findViewById(R.id.web);
        web.getSettings().setJavaScriptEnabled(true);
        web.loadUrl(video);
        probar2.setVisibility(View.GONE);

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });

        adview = findViewById(R.id.adView);

        AdRequest adRequest = new AdRequest.Builder().build();
        adview.loadAd(adRequest);

    }
}