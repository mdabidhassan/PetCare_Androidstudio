package com.dmart.bdpetcare;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

public class DOGINFO extends AppCompatActivity {
    CardView disease,food,dvaccine,wonwecare,care,potty;
    AdView adview,adview2;
    ImageView back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doginfo);

        if (Build.VERSION.SDK_INT>= Build.VERSION_CODES.LOLLIPOP){
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
            getWindow().setStatusBarColor(Color.TRANSPARENT);

        }else {

            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

        }
potty=findViewById(R.id.dogpotty);
      care=findViewById(R.id.dogcare);
       disease=findViewById(R.id.dogdisease);
        food=findViewById(R.id.dogfood);
        dvaccine=findViewById(R.id.dogvaccine2);
       wonwecare=findViewById(R.id.dogowner);



        back=findViewById(R.id.shoplink);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(DOGINFO.this,MainActivity.class);
                startActivity(intent);
            }
        });







        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });

        adview = findViewById(R.id.adView);


        AdRequest adRequest = new AdRequest.Builder().build();
        adview.loadAd(adRequest);








        potty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(DOGINFO.this,Dogpotty.class);
                startActivity(intent);
            }
        });



        care.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(DOGINFO.this,DOGCARE.class);
                startActivity(intent);
            }
        });



        disease.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(DOGINFO.this,DOGDISEASE.class);
                startActivity(intent);
            }
        });


        food.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(DOGINFO.this,DOGFOOD.class);
                startActivity(intent);
            }
        });


      dvaccine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(DOGINFO.this,DOgVaccine.class);
                startActivity(intent);
            }
        });

        wonwecare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(DOGINFO.this,Dogowner.class);
                startActivity(intent);
            }
        });


    }
}
