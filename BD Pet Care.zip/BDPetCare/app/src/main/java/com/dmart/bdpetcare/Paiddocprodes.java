package com.dmart.bdpetcare;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

public class Paiddocprodes extends AppCompatActivity {

    TextView docname,docdetails,docfee;
    ImageView docimage,back,doclink,emergency;

    public String num="";
    AdView adview,adView2;
    public static String Docname ="";
    public static Bitmap bitmap=null;

    public static String Docfee="";

    public static String Doclink ="";
    public static String Docdetails ="";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paiddocprodes);
        if (Build.VERSION.SDK_INT>= Build.VERSION_CODES.LOLLIPOP){
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
            getWindow().setStatusBarColor(Color.TRANSPARENT);

        }else {

            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

        }

        doclink=findViewById(R.id.doclink)   ;
        emergency=findViewById(R.id.emergency);
        back=findViewById(R.id.back);

        docimage=findViewById(R.id.docimage);
        docfee=findViewById(R.id.docfee);
        docdetails=findViewById(R.id.docdetails);
        docname=findViewById(R.id.docname);


         docfee.setText(Docfee);

        docdetails.setText(Docdetails);
        docname.setText(Docname);

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });

        adview = findViewById(R.id.adView);

        AdRequest adRequest = new AdRequest.Builder().build();
        adview.loadAd(adRequest);

        if(bitmap!=null)docimage.setImageBitmap(bitmap);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Paiddocprodes.this,MainActivity.class);
                startActivity(intent);
            }
        });



        doclink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String number ="+88"+Doclink;
                String url = "https://api.whatsapp.com/send?phone="+number;
                Intent wpIntent = new Intent(Intent.ACTION_VIEW);
                wpIntent.setData(Uri.parse(url));
                startActivity(wpIntent);


            }
        });

        emergency.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("fb://messaging/" + "61551730176797"));
                startActivity(i);


            }
        });





    }


    private void showDialog() {


        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder
                .setTitle("MESSAGE")
                .setMessage("আপনি শুধু মাত্র একজন ভেটের কনসাল্ট নিতে পারবেন,একটিভ থাকা একাধিক ভেটকে নক করলে, কোন কনসাল্ট পাবেন না।")
                .setCancelable(false)
                .setNegativeButton("রাজি না", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {



                    }
                })
                .setPositiveButton("রাজি", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // Do something when OK is clicked

                        String number ="+88"+Doclink;
                        String url = "https://api.whatsapp.com/send?phone="+number;
                        Intent wpIntent = new Intent(Intent.ACTION_VIEW);
                        wpIntent.setData(Uri.parse(url));
                        startActivity(wpIntent);

                    }
                });

        // Create and show the dialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}