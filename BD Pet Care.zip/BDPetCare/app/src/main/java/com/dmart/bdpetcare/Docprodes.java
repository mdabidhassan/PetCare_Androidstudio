package com.dmart.bdpetcare;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Docprodes extends AppCompatActivity {
    TextView docname,docdetails,docfee;
    ImageView docimage,back,doclink,emergency;

    public String num="";
    AdView adview,adView2;
    public static String Docname ="";
    public static Bitmap bitmap=null;

    public static String Docfee="";

    public static String Doclink ="";
    public static String Docdetails ="";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_docprodes);
        if (Build.VERSION.SDK_INT>= Build.VERSION_CODES.LOLLIPOP){
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
            getWindow().setStatusBarColor(Color.TRANSPARENT);

        }else {

            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

        }

        doclink=findViewById(R.id.doclink)   ;
        emergency=findViewById(R.id.emergency);
        back=findViewById(R.id.back);

        docimage=findViewById(R.id.docimage);
        docfee=findViewById(R.id.docfee);
       docdetails=findViewById(R.id.docdetails);
        docname=findViewById(R.id.docname);


       // docfee.setText(Docfee);

       docdetails.setText(Docdetails);
        docname.setText(Docname);

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });

        adview = findViewById(R.id.adView);

        AdRequest adRequest = new AdRequest.Builder().build();
        adview.loadAd(adRequest);

        if(bitmap!=null)docimage.setImageBitmap(bitmap);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Docprodes.this,MainActivity.class);
                startActivity(intent);
            }
        });




        emergency.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("fb://messaging/" + "61551730176797"));
                startActivity(i);


            }
        });



        String url="https://petcarebd.xyz/DOCTOR/code.json";

        JsonArrayRequest jsnarry =new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {

                try {
                    for (int x=0;x<response.length();x++){


                        JSONObject object= response.getJSONObject(0);

                        String version=object.getString("name");

                        doclink.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {

                                AlertDialog.Builder builder = new AlertDialog.Builder(Docprodes.this);
                                builder
                                        .setTitle("MESSAGE")
                                        .setMessage("আপনি  ডক্টরক মেসেজ দেওয়ার সময় অবশ্যই আমাদের কোড ব্যাবহার করবেন । কোড নম্বর লিখে তারপর ডক্টরকে সমস্যা বলুন ! কোড ব্যাবহার ছাড়া আমাদের ডক্টরা কোন সেবা দিবেন না। \n" +
                                                "কোড প্রতিদিন পরিবর্তন হয়। তাই কোড পেতে হলে আমাদের এপ থেকে ম্যাসেজ করুন অন্যথায় সেবা থেকে বঞ্চিত হবেন।  ধন্যবাদ\n" +
                                                "কোড : "+version)
                                        .setCancelable(false)
                                        .setNegativeButton("রাজি না", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialogInterface, int i) {



                                            }
                                        })
                                        .setPositiveButton("রাজি", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                // Do something when OK is clicked

                                                String number ="+88"+Doclink;
                                                String url = "https://api.whatsapp.com/send?phone="+number;
                                                Intent wpIntent = new Intent(Intent.ACTION_VIEW);
                                                wpIntent.setData(Uri.parse(url));
                                                startActivity(wpIntent);

                                            }
                                        });

                                // Create and show the dialog
                                AlertDialog dialog = builder.create();
                                dialog.show();

                            }
                        });

                    }









                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }



        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {


            }
        });

//..2.................................................................................................................//
        RequestQueue queue= Volley.newRequestQueue(Docprodes.this);
        queue.add(jsnarry);











    }


    private void showDialog() {


        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder
                .setTitle("MESSAGE")
                .setMessage("আপনি অবশ্যই  ডক্টরক মেসেজ দেওয়ার সময় অবশ্যই আমাদের কোড ব্যাবহার করবেন। কোড ব্যাবহার ছাড়া আমাদের ডক্টরা কোন সেবা দিবেন না। \\n\" +\n" +
                        "                        \"কোড প্রতিদিন পরিবর্তন হয়। তাই কোড পেতে হলে আমাদের এপ থেকে ম্যাসেজ করুন অন্যথায় সেবা থেকে বঞ্চিত হবেন।  ধন্যবাদ\\n\" +\n" +
                        "                        \"কোড :")
                .setCancelable(false)
                .setNegativeButton("রাজি না", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {



                    }
                })
                .setPositiveButton("রাজি", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // Do something when OK is clicked

                        String number ="+88"+Doclink;
                        String url = "https://api.whatsapp.com/send?phone="+number;
                        Intent wpIntent = new Intent(Intent.ACTION_VIEW);
                        wpIntent.setData(Uri.parse(url));
                        startActivity(wpIntent);

                    }
                });

        // Create and show the dialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}